<?php echo $__env->make('front-end.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Start Page Title Area -->
<!-- <div class="page-title">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <h3>Login</h3>
            </div>
        </div>
    </div>
</div> -->
<!-- End Page Title Area -->

<!-- Start Login Area -->
<section class="login-area ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
            <div class="register-content">
                <div class="heading">Login</div>
                <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                    <div class="left" >
                        <div class="form-group">
                            <label>Useremail</label>
                            <input type="text" name="email" class="form-control" placeholder="email">
                        </div>
                        
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Password">
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                </form>
                <h4>Are you a member? <a href="/signUp">Sign Up Now!</a></h4>
            </div>
            </div>
        </div>
    </div>
</section>
<!-- End Login Area -->
        
<?php echo $__env->make('front-end.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\www\fared-hadi\resources\views/front-end/auth/login.blade.php ENDPATH**/ ?>